# motion_detection/__init__.py
from .detector import MotionDetector