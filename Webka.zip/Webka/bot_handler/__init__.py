# bot_handler/__init__.py
from .bot import bot, dp, start_bot_polling, broadcast_alert
from . import state as bot_state
