# bot_handler/state.py
monitoring_active = False
current_mode = "photo"

